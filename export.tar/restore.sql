--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.appointment (
    id_appointment integer NOT NULL,
    studentid integer,
    tutorid integer,
    slot character varying,
    accepted boolean
);


ALTER TABLE public.appointment OWNER TO postgres;

--
-- Name: appointment_idAppointment_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."appointment_idAppointment_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."appointment_idAppointment_seq" OWNER TO postgres;

--
-- Name: appointment_idAppointment_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."appointment_idAppointment_seq" OWNED BY public.appointment.id_appointment;


--
-- Name: course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course (
    idcourse integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.course OWNER TO postgres;

--
-- Name: course_idsubject_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_idsubject_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_idsubject_seq OWNER TO postgres;

--
-- Name: course_idsubject_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_idsubject_seq OWNED BY public.course.idcourse;


--
-- Name: history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.history (
    idhistory integer NOT NULL,
    starttime timestamp without time zone NOT NULL,
    endtime timestamp without time zone NOT NULL,
    tutorrating double precision,
    tutorcomment text
);


ALTER TABLE public.history OWNER TO postgres;

--
-- Name: history_idhistory_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.history_idhistory_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.history_idhistory_seq OWNER TO postgres;

--
-- Name: history_idhistory_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.history_idhistory_seq OWNED BY public.history.idhistory;


--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    username character varying(20) NOT NULL,
    password character varying(20) NOT NULL,
    idstudent integer NOT NULL,
    firstname character varying,
    lastname character varying,
    education character varying,
    yearofbirth character varying
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Name: student_idstudent_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.student ALTER COLUMN idstudent ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.student_idstudent_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor (
    idtutor integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    firstname character varying,
    lastname character varying,
    education character varying,
    yearofbirth character varying,
    location character varying NOT NULL,
    approved boolean,
    rateperhour character varying
);


ALTER TABLE public.tutor OWNER TO postgres;

--
-- Name: tutor_availability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_availability (
    id integer NOT NULL,
    tutor_id integer,
    availability character varying,
    booked boolean
);


ALTER TABLE public.tutor_availability OWNER TO postgres;

--
-- Name: tutor_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tutor_availability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tutor_availability_id_seq OWNER TO postgres;

--
-- Name: tutor_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tutor_availability_id_seq OWNED BY public.tutor_availability.id;


--
-- Name: tutor_has_course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutor_has_course (
    tutor_idtutor integer NOT NULL,
    course_idcourse integer NOT NULL
);


ALTER TABLE public.tutor_has_course OWNER TO postgres;

--
-- Name: tutor_idtutor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tutor ALTER COLUMN idtutor ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tutor_idtutor_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: appointment id_appointment; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment ALTER COLUMN id_appointment SET DEFAULT nextval('public."appointment_idAppointment_seq"'::regclass);


--
-- Name: course idcourse; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course ALTER COLUMN idcourse SET DEFAULT nextval('public.course_idsubject_seq'::regclass);


--
-- Name: history idhistory; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history ALTER COLUMN idhistory SET DEFAULT nextval('public.history_idhistory_seq'::regclass);


--
-- Name: tutor_availability id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_availability ALTER COLUMN id SET DEFAULT nextval('public.tutor_availability_id_seq'::regclass);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.appointment (id_appointment, studentid, tutorid, slot, accepted) FROM stdin;
\.
COPY public.appointment (id_appointment, studentid, tutorid, slot, accepted) FROM '$$PATH$$/3231.dat';

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course (idcourse, name) FROM stdin;
\.
COPY public.course (idcourse, name) FROM '$$PATH$$/3219.dat';

--
-- Data for Name: history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.history (idhistory, starttime, endtime, tutorrating, tutorcomment) FROM stdin;
\.
COPY public.history (idhistory, starttime, endtime, tutorrating, tutorcomment) FROM '$$PATH$$/3221.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student (username, password, idstudent, firstname, lastname, education, yearofbirth) FROM stdin;
\.
COPY public.student (username, password, idstudent, firstname, lastname, education, yearofbirth) FROM '$$PATH$$/3223.dat';

--
-- Data for Name: tutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor (idtutor, username, password, firstname, lastname, education, yearofbirth, location, approved, rateperhour) FROM stdin;
\.
COPY public.tutor (idtutor, username, password, firstname, lastname, education, yearofbirth, location, approved, rateperhour) FROM '$$PATH$$/3225.dat';

--
-- Data for Name: tutor_availability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_availability (id, tutor_id, availability, booked) FROM stdin;
\.
COPY public.tutor_availability (id, tutor_id, availability, booked) FROM '$$PATH$$/3229.dat';

--
-- Data for Name: tutor_has_course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutor_has_course (tutor_idtutor, course_idcourse) FROM stdin;
\.
COPY public.tutor_has_course (tutor_idtutor, course_idcourse) FROM '$$PATH$$/3226.dat';

--
-- Name: appointment_idAppointment_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."appointment_idAppointment_seq"', 6, true);


--
-- Name: course_idsubject_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_idsubject_seq', 8, true);


--
-- Name: history_idhistory_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.history_idhistory_seq', 1, false);


--
-- Name: student_idstudent_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_idstudent_seq', 25, true);


--
-- Name: tutor_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tutor_availability_id_seq', 10, true);


--
-- Name: tutor_idtutor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tutor_idtutor_seq', 10, true);


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (id_appointment);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (idcourse);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (idhistory);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (idstudent);


--
-- Name: tutor_availability tutor_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_availability
    ADD CONSTRAINT tutor_availability_pkey PRIMARY KEY (id);


--
-- Name: tutor_has_course tutor_has_course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor_has_course
    ADD CONSTRAINT tutor_has_course_pkey PRIMARY KEY (tutor_idtutor, course_idcourse);


--
-- Name: tutor tutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutor
    ADD CONSTRAINT tutor_pkey PRIMARY KEY (idtutor);


--
-- Name: history course_idcourse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT course_idcourse_fkey FOREIGN KEY (idhistory) REFERENCES public.course(idcourse) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: history student_idstudent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT student_idstudent_fkey FOREIGN KEY (idhistory) REFERENCES public.student(idstudent) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: history tutor_idtutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.history
    ADD CONSTRAINT tutor_idtutor_fkey FOREIGN KEY (idhistory) REFERENCES public.tutor(idtutor) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

